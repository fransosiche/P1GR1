#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "donnees.h"

int main()
{
    int choix;
    // printf("%d", Menu_De_Base(choix));
    OuvertureFichier();
    return 0;
}
