#include <stdio.h>
#ifndef __LIST__H__
#define __LIST__H__
#endif


	/* D�finition du type Bool�en */
	typedef enum
	{
		false,
		true
	}Bool;

	/* D�finition d'une File */
	typedef struct QueueElement
	{
		char value[10];
		struct QueueElement *next;
	}QueueElement, *Queue;

	/* Param�tres de la File */
	static QueueElement *first = NULL;
	static QueueElement *last = NULL;
	static int nb_elements = 0;

	/* Prototypes */
	Bool is_empty_queue(void);
	int queue_length(void);
	int queue_first(void);
	int queue_last(void);
	void print_queue(void);
	void push_queue(char x[10]);
	void pop_queue(void);
	void clear_queue(void);
